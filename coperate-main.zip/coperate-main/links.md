repo link : https://github.com/Zysoftec19/corporate-order-frontend

figma link : https://www.figma.com/file/1FTadBtFLrAyKOpRzap5Wa/card_dashboard?type=design&mode=design&t=IOMrKILufnBveSLi-1
