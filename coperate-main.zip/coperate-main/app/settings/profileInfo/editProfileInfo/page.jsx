import DashboardWrapper from '@/components/Dashboard/Dashboard-Wrapper'
import EditUser from '@/components/editUserInfo/EditeUser'
import React from 'react'

const page = () => {
  return (
    <>
    <EditUser/>
    </>
  )
}

export default page
